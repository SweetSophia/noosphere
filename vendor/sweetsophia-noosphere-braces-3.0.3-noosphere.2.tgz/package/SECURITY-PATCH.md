# Private local patch candidate

This package is a privately maintained derivative of npm `braces@3.0.3`,
not an upstream release or an independently certified security fix.
Its upstream MIT license and attribution are retained.

The published advisory GHSA-vfj7-8cjw-p6xm describes uncontrolled recursion
and has no listed upstream fixed version at the time of this assessment.

Local changes:

- String parsing enforces a non-configurable limit of 64 nested containers.
- Compile, stringify, and expand also accept existing AST objects. Their
  internal entry points now inspect child edges iteratively before recursion,
  rejecting child cycles and depths above 65 edges. The extra edge permits
  leaf nodes beneath 64 parsed containers.
- Expansion's parent-chain walks have a fixed hop limit as well.
- The validator expects AST child lists to be arrays. Parser-produced cyclic
  parent/previous backlinks are deliberately excluded from child traversal.

Limits are intentional compatibility restrictions. This patch is not a general
resource quota for expansion cardinality, arbitrary getters/proxies, or all
possible JavaScript objects. Existing expansion range limits are unchanged.

The standalone regression probe is explicitly skipped by owner instruction.
No replacement or stress/boundary probes are authorized. The earlier ordinary
root install/lint/typecheck/build results apply to the previous parser-only
candidate, not automatically to this revision. Further ordinary validation is
required before integration. Registry audit inventory for a renamed private
package is not evidence that its implementation is safe.
